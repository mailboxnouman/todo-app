
const btn = document.getElementById('menu-btn')
const tmb = document.getElementById('top')
const mtb = document.getElementById('middle')
const btm = document.getElementById('bottom')
const nav = document.getElementById('menu')

btn.addEventListener('click', () => {
    btn.classList.toggle('open')
    btn.classList.toggle('bgWhite')
    tmb.classList.toggle('tmb')
    mtb.classList.toggle('tmb')
    btm.classList.toggle('tmb')
    nav.classList.toggle('flex')
    nav.classList.toggle('hidden')
    if (btn.className === "bgWhite") {
      btn.style.background = "black"
    }else{
      btn.style.background = "transparent"
    }
    if (menu.className === "hidden") {
      nav.style.animationName = "bottomToTop"
    }else{
      nav.style.animationName= "topToBottom";

    }
})
// btn.addEventListener("click", function() {
//  })


document.addEventListener("DOMContentLoaded", function() {
  var today = new Date();

  var dayOfWeek = today.getDay();

  var daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  var todayName = daysOfWeek[dayOfWeek];

  document.getElementById("day").innerText = todayName


  var hours = today.getHours();
  var minutes = today.getMinutes();

  var formattedHours = (hours % 12 || 12).toString().padStart(2, '0');
  var ampm = hours >= 12 ? 'PM' : 'AM';

  var formattedMinutes = minutes.toString().padStart(2, '0');

  var formattedTime = formattedHours + ":" + formattedMinutes + " " + ampm;

  document.getElementById("time").innerText = formattedTime;

});

// document.addEventListener("DOMContentLoaded", function() {
//   var nav = document.getElementById("menu");
//   nav.style.animationName = "none";

// });






var add = document.getElementById("add");
var container3 = document.getElementById("container3");
var container4 = document.getElementById("container4");

add.addEventListener("click", function() {
    if (add.innerText === "Cancel") {
        // Logic for "Cancel" button state
        add.innerText = "Add new";
        container3.style.position = "absolute";
        container3.style.animationName = "rgtToLft";
        container3.style.zIndex = "-1";
        container4.style.animationName = "btmToTop";
    } else {
        // Logic for "Add new" button state
        add.innerText = "Cancel";
        add.style.color = "#4044C9";
        add.style.fontWeight = "600";
        add.style.fontSize = ".9rem";
        container3.style.position = "relative";
        container3.style.animationName = "lftToRgt";
        container3.style.zIndex = "1";
        container4.style.animationName = "tpToBtm";
    }
});




function checkListItems() {
  var taskList = document.getElementById("taskList");
  var noElFound = document.getElementById("noElFound")
  var listItems = taskList.getElementsByTagName("li");

  if (listItems.length === 0) {
    noElFound.style.display = "block"
  } else {
    noElFound.style.display = "none"
  }
}






document.addEventListener("DOMContentLoaded", function() {
  checkListItems();

  var addTaskBtn = document.getElementById("addTaskBtn");
  addTaskBtn.addEventListener("click", function() {
      checkListItems();
  });
});
    

document.addEventListener("DOMContentLoaded", function() {
  var taskInput = document.getElementById("taskInput");

  taskInput.addEventListener("input", function() {
      this.rows = 1;
      this.rows = Math.ceil(this.scrollHeight / 50); 
    });

  taskInput.addEventListener("input", function() {
      var lines = this.value.split("\n");
      var lineCount = lines.length;

      if (lineCount > this.rows) {
          this.rows = lineCount;
      }
  });
}); 
    


    
    function addTask() {
      
      var taskInput = document.getElementById('taskInput');
      var taskDateInput = document.getElementById('taskDate');
      var taskStartTimeInput = document.getElementById('taskStartTime');
      var taskEndTimeInput = document.getElementById('taskEndTime');
      var taskList = document.getElementById('taskList');

      if (taskInput.value.trim() !== "") {
        var taskItem = document.createElement('li');
        taskItem.className = 'taskItem';
        
        var inputBox = document.createElement('textarea');
        inputBox.className = 'taskInput';
        inputBox.value = taskInput.value;
        taskItem.style.animationName = "lftToRgt"
        taskItem.style.animationDuration = ".5s"
        


        taskItem.appendChild(inputBox);
        inputBox.disabled = true;
        
        if (taskDateInput.value !== ""){
        var selectedDate = taskDateInput.value;
        var dateInputBox = document.createElement('input');
        dateInputBox.className = 'taskDate';
        dateInputBox.type = 'date';
        dateInputBox.disabled = true;
        taskItem.appendChild(dateInputBox);
        dateInputBox.value = selectedDate;
      }
        
        if (taskStartTimeInput.value !== ""){
        var selectedStartTime = taskStartTimeInput.value;
        var startTimeInputBox = document.createElement('input');
        startTimeInputBox.className = 'taskStartTime';
        startTimeInputBox.type = 'time';
        startTimeInputBox.disabled = true;
        taskItem.appendChild(startTimeInputBox);
        startTimeInputBox.value = selectedStartTime;
      }
        if (taskEndTimeInput.value !== ""){
        var selectedEndTime = taskEndTimeInput.value;
        var endTimeInputBox = document.createElement('input');
        endTimeInputBox.className = 'taskEndTime';
        endTimeInputBox.type = 'time';
        endTimeInputBox.disabled = true;
        taskItem.appendChild(endTimeInputBox);
        endTimeInputBox.value = selectedEndTime;
      }


     
        var editBtn = document.createElement('span');
        editBtn.className = 'editBtn';
        editBtn.innerHTML = ' <i class="fa-solid fa-pen"></i>';
        editBtn.onclick = function() {
          inputBox.disabled = false;
          if (dateInputBox){
          dateInputBox.disabled = false;
        }
          if (startTimeInputBox){
            startTimeInputBox.disabled = false;
        }
          if (endTimeInputBox){
            endTimeInputBox.disabled = false;
        }
          

          var saveBtn = taskItem.querySelector('.saveBtn');


          if (!saveBtn) {
            saveBtn = document.createElement('span');
            saveBtn.className = 'saveBtn';
            saveBtn.innerHTML = ' <i class="fa-solid fa-circle-check"></i>';
            taskItem.appendChild(saveBtn);
        }

        saveBtn.onclick = function() {
          inputBox.disabled = true;
          if (dateInputBox){
            dateInputBox.disabled = true;
          }
            if (startTimeInputBox){
              startTimeInputBox.disabled = true;
          }
            if (endTimeInputBox){
              endTimeInputBox.disabled = true;
          }

          taskItem.removeChild(saveBtn);
        }
          // // var updatedTask = prompt('Edit the task:', taskInput.value);
          // // if (updatedTask !== null) {
          // //   var updatedTaskDate = taskDate ? taskDate.toLocaleDateString() : '';
          // //   inputBox.value = updatedTask;
          //   taskText.nodeValue = `[${updatedTaskDate}] ${timePeriod}`;
          // }
        };

        var deleteBtn = document.createElement('span');
        deleteBtn.className = 'deleteBtn';
        deleteBtn.innerHTML = '<i class="fa-solid fa-circle-xmark"></i>';
        deleteBtn.onclick = function() {
          taskList.removeChild(taskItem);
          checkListItems();
        };

        taskItem.appendChild(editBtn);

        taskItem.appendChild(deleteBtn);

        taskList.appendChild(taskItem);

        taskInput.value = "";
        taskDateInput.value = "";
        taskStartTimeInput.value = "";
        taskEndTimeInput.value = "";
      }
    }
 
